=== Standard Student Information ===
Contributors: shobujkhan
Tags: sabuj, personal, sabuj info, personal info, info, student employee, student info, student,s information
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Standard Student information plugin is used to add all the data of students. And you can search any student by using serching shortcode.  

== Description ==

The plugin is being used to add the employee's personal information. Using this plugin we can add the personal information of students, teachers, doctors, employees, etc. You can add and show the student's all information using this standard Student Information plugin.

Note: To use this plugin with any theme, you have to copy two files from plugin folder and paste in the theme folder. To find that files, go to plugin folder, then templates and inside templates folder you can see two files named all-students.php and student.php.

You have to use this shortcode "student-search" for searching option. For the search form you have to use this shortcode.


== Frequently Asked Questions ==

= Can the plugin be used with both classic editor and block editor? =

Yes, this plugin is compatible with all editors.

= Is it possible to edit the plugin root file? =

Of course, you can edit the files as you need.


