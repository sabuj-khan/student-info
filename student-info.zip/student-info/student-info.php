<?php
/*
Plugin Name: Standard Student Information
Plugin URI: https://sabuj.mokam24.com/demo/plugins/
Author: Mohammad Sabuj Khan
Author URI: https://sabuj.mokam24.com
Version: 1.0.0
Description: The plugin is being used to add the personal information. Using this pugin we can add personal info if student, teacher, doctors, Student etc
Tags: sabuj, personal, sabuj info, personal info, info, information
Text Domain: student_info
Domain Path: /languages
*/

/*
    Note: To use this plugin with any theme, you have to copy two files from plugin folder and paste in the theme folder. To find that files, go to plugin folder, then templates and inside templates folder you can see two files named all-students.php and student.php. 
    

*/

class StudentInfo {
    public function __construct(){
        add_action('plugins_loaded', array( $this, 'student_info_text_domain_setup'));
        add_action('init', array($this, 'student_info_student_post_type'));
        add_action('add_meta_boxes', array($this, 'student_info_student_meta_info'));
        add_action('save_post', array($this, 'student_info_student_save_post'));
        add_shortcode('student-search', array($this, 'student_info_student_seraching'));
        add_filter('template_include', array($this, 'student_info_student_template_include'));
        
    }

    public function student_info_text_domain_setup(){
        load_plugin_textdomain( 'student_info', false, plugin_dir_path(__FILE__).'/languages' );
    }
    
    // Student Post Type creation
    public function student_info_student_post_type(){
        $labels	   = array(
			'name'               => _x( 'Students', 'Post type general name', 'student_info' ),
            'singular_name'      => _x( 'Student', 'Post type singular name', 'student_info' ),
            'menu_name'          => _x( 'Students', 'Admin Menu text', 'student_info' ),
            'name_admin_bar'     => _x( 'Student', 'Add New on Toolbar', 'student_info' ),
            'add_new'            => __( 'Add New Student', 'student_info' ),
            'add_new_item'       => __( 'Add New Student', 'student_info' ),
            'new_item'           => __( 'New Student', 'student_info' ),
            'edit_item'          => __( 'Edit Student', 'student_info' ),
            'view_item'          => __( 'View Student', 'student_info' ),
            'all_items'          => __( 'All Students', 'student_info' ),
		);
        
        $arguments = array(
            'labels'             => $labels,
            'description'        => 'Students custom post type.',
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'Student' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => true,
            'menu_position'      => NULL,
            'menu_icon'			 => 'dashicons-groups',
            'supports'           => array( 'title', 'editor', 'thumbnail' ),
            'show_in_rest'       => true
         );
         
        register_post_type('info-student', $arguments);

        // Taxonomy includding

	$labeell = array(
		'name'			=> __( 'Student Types', 'student_info'),
		'singular_name' => __( 'Student Type', 'student_info'),
		'add_new_item'	=> __( 'Add New Type', 'student_info'),
		'add_new'		=> __( 'Add New Type', 'student_info'),
		'new_item'      => __( 'New Type', 'student_info'),
		'edit_item'		=> __( 'Edit Type', 'student_info'),
	);
	$arguuu = array(
		'labels'             => $labeell,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'query_var'          => true,
		'hierarchical'       => true,
		'rewrite'            => array('slug' => 'type'),
	);

	register_taxonomy( 'stu-type', 'info-student', $arguuu );
    }

    // Meta options include

    public function student_info_student_meta_info(){
        add_meta_box('add-student-info', 'Student Additional Information', array($this, 'student_individual_information'), 'info-student');
    }
    public function student_individual_information(){

        $v_class = get_post_meta(get_the_ID(), '_student_class', true);
        $v_secti = get_post_meta(get_the_ID(), '_student_section', true);
        $v_roll = get_post_meta(get_the_ID(), '_student_roll', true);
        $v_age = get_post_meta(get_the_ID(), '_student_age', true);
        
        ?>

        <p>
			<label for="class">Student Class:</label>
			<select name="class" id="class">
				<?php 
					$numb = 0;
				while( $numb < 10 ): 
					$numb++;
				?>
				<option value="<?php echo $numb; ?>"<?php if( $numb == $v_class){ echo "selected='selected'";} ?>>Class <?php echo $numb; ?></option>
				<?php endwhile; ?>
			</select>
		</p>

        <p>
			<label for="class">Student Sections:</label>
			<select name="section" id="section">
			
				<option value="a"<?php if( $v_secti == 'a'){ echo "selected='selected'";} ?>>Sections A</option>
				<option value="b"<?php if( $v_secti == 'b'){ echo "selected='selected'";} ?>>Sections B</option>
				<option value="c"<?php if( $v_secti == 'c'){ echo "selected='selected'";} ?>>Sections C</option>
				<option value="d"<?php if( $v_secti == 'd'){ echo "selected='selected'";} ?>>Sections D</option>
				
			</select>
		</p>

        <p>
			<label for="roll">Student's Roll:</label>
			<input type="number", name="roll" id="roll" value="<?php echo $v_roll; ?>">
		</p>
		<p>
			<label for="age">Student's Age:</label>
			<input type="number", name="age" id="age" value="<?php echo $v_age; ?>">
		</p>


        <?php
    }

    // Save and update all posts

    public function student_info_student_save_post($postid){

        $sclass = isset($_REQUEST['class']) ? $_REQUEST['class'] : '';
        $ssection = isset($_REQUEST['section']) ? $_REQUEST['section'] : '';
        $sroll = isset($_REQUEST['roll']) ? $_REQUEST['roll'] : '';
        $sage = isset($_REQUEST['age']) ? $_REQUEST['age'] : '';

        update_post_meta( $postid, '_student_class', $sclass);
        update_post_meta( $postid, '_student_section', $ssection);
        update_post_meta( $postid, '_student_roll', $sroll);
        update_post_meta( $postid, '_student_age', $sage);
    }


    // Shortcode creation 

    public function student_info_student_seraching(){
            global $post;
            $pageid = $post->ID;
            $url = get_permalink($pageid);
        ob_start();  ?>
            
            <form action="<?php echo $url; ?>" method="GET">
            <input type="hidden" name="search" value="student">

            <input type="text" name="n_student" placeholder="Student's Name">
            
                <select name="class" id="class">
                <option value="">Select Class</option>
                    <?php 
                        $numb = 0;
                    while( $numb < 10 ): 
                        $numb++;
                    ?>
                    <option value="<?php echo $numb; ?>">Class <?php echo $numb; ?></option>
                    <?php endwhile; ?>
                </select>

                <select name="section" id="section">
                    <option value="">Select Section</option>			
                    <option value="a">Sections A</option>
                    <option value="b">Sections B</option>
                    <option value="c">Sections C</option>
                    <option value="d">Sections D</option>				
			    </select>
                <input type="submit" value="Search">
            
            </form>


        <?php return ob_get_clean();
    }

    public function student_info_student_template_include($default){

        if( isset($_REQUEST['search']) && $_REQUEST['search'] == 'student' ){ 
            $default = locate_template('student.php');
        }

       return $default;
    }

    
} 

$studentinfo = new StudentInfo();