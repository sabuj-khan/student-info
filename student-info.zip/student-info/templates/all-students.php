<?php 
/*
Template Name: Students
*/
get_header(); ?>

<div class="student">
    <div class="content-area">
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
    </div>
    <div class="show-student">
        <?php 

           


            $all_studen = new WP_Query( array(
                'post_type'         => 'info-student',
                'posts_per_page'    => -1,
            ) );

        while( $all_studen->have_posts() ) : $all_studen->the_post(); ?>

            <div class="all-stu-info">
                <div class="left-info">
                    <div class="stu-title"><h3><?php the_title(); ?></h3></div>
                    <div class="ti-thum">
                        <?php the_post_thumbnail('medium'); ?>
                    </div>

                    <?php
                        $class_va = get_post_meta(get_the_ID(), '_student_class', true);
                        $section_va = get_post_meta(get_the_ID(), '_student_section', true);
                        $roll_va = get_post_meta(get_the_ID(), '_student_roll', true);
                        $age_va = get_post_meta(get_the_ID(), '_student_age', true);
                    ?>

                    <div class="meta-info">
                        <p><strong>Student's Class:  <?php echo $class_va; ?> </strong> </p>          

                        <p><strong>Student's Section:  <?php echo strtoupper($section_va); ; ?> </strong> </p> 

                        <p><strong>Student's Roll:  <?php echo $roll_va; ?> </strong> </p>

                        <p><strong>Student's Age:  <?php echo $age_va; ?> </strong> </p>

                        <p><strong>Student's Type:  <?php 

                        $studentss = get_the_terms(get_the_id(), 'stu-type' );
                        if( $studentss ) {
                            foreach( $studentss as $students ){
                                echo $students->name;
                            }
                        }
                        

                        ?> </strong> </p>
                    </div>
                </div>

                <div class="right-info">
                    <?php the_content(); ?>
                    <hr>
                </div>   
            </div>             

                

        <?php endwhile; ?>
    </div>
</div>


<?php get_footer(); ?>