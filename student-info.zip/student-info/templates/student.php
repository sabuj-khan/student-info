<?php get_header(); ?>

    <div class="student">
        <?php 

        

        $meta_class = isset($_REQUEST['class']) ? $_REQUEST['class'] : '';
        $meta_secti = isset($_REQUEST['section']) ? $_REQUEST['section'] : '';
        $s_name     = isset($_REQUEST['n_student']) ? $_REQUEST['n_student'] : '';

        $inf_student = new WP_Query( array(
            'post_type'         => 'info-student',
            'posts_per_page'    => -1,
            's'             => $s_name,
            'meta_query'        => array(
                'relation'      => 'AND',
                array(
                    'key'       => '_student_class',
                    'value'     => $meta_class,
                    'compare'   => 'LIKE',
                ),
                array(
                    'key'       => '_student_section',
                    'value'     => $meta_secti,
                    'compare'   => 'LIKE',
                ),
            ),
        ) );

        if( $inf_student->have_posts() ) : 

        while( $inf_student->have_posts() ) : $inf_student->the_post(); ?>

            <div class="all-stu-info">
                <div class="left-info">
                    <div class="stu-title"><h3><?php the_title(); ?></h3></div>
                    <div class="ti-thum">
                        <?php the_post_thumbnail('medium'); ?>
                    </div>

                    <div class="meta-info">
                        <p><strong>Student's Class:  <?php echo get_post_meta(get_the_ID(), '_student_class', true); ?> </strong> </p>          

                        <p><strong>Student's Section:  <?php echo strtoupper(get_post_meta(get_the_ID(), '_student_section', true)); ?> </strong> </p> 

                        <p><strong>Student's Roll:  <?php echo get_post_meta(get_the_ID(), '_student_roll', true); ?> </strong> </p>

                        <p><strong>Student's Age:  <?php echo get_post_meta(get_the_ID(), '_student_age', true); ?> </strong> </p>

                        <p><strong>Student's Type:  <?php 

                        $studentss = get_the_terms(get_the_id(), 'stu-type' );

                        if( $studentss ) {
                            foreach( $studentss as $students ){
                                echo $students->name;
                            }
                        }

                        ?> </strong> </p>
                    </div>
                </div>

                <div class="right-info single-info">
                    <?php the_content(); ?>
                    <hr>
                </div>   
            </div>             



        <?php endwhile; ?>

        <?php else: ?>

            <h2>No student founds</h2>

        <?php endif; ?>
    </div>


<?php get_footer(); ?>


